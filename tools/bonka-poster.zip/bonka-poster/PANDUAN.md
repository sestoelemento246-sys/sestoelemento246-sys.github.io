# BONKA Auto Poster — Panduan

Tool untuk upload video ke TikTok secara otomatis/terjadwal lewat API resmi TikTok.
Bisa dipakai manual dari Terminal, atau dijalankan agen AI (Hermes).

## 1. Pasang (sekali saja, di Mac)
1. Ekstrak zip ini, pindahkan folder `bonka-poster` ke folder home Anda
   (sehingga ada `~/bonka-poster/bonka_poster.py`).
2. Buka **Terminal**, jalankan:

       cd ~/bonka-poster
       python3 bonka_poster.py setup

   Masukkan **Client key** dan **Client secret** dari developers.tiktok.com
   (tab **Sandbox → BONKA Test** selama app belum lolos review).
   Data disimpan di `~/.bonka-poster/` (hanya di komputer Anda).

## 2. Hubungkan akun TikTok
    python3 bonka_poster.py login --name bonka

Browser terbuka → login TikTok → Authorize → halaman BONKA menampilkan kode →
klik **Copy code** → tempel di Terminal. Ulangi dengan `--name` lain untuk akun kedua.
Cek: `python3 bonka_poster.py accounts`

## 3. Posting
Sekarang juga:

    python3 bonka_poster.py post --account bonka --file ~/Videos/a.mp4 --caption "Promo! #bonka" --brand-organic

Terjadwal:

    python3 bonka_poster.py schedule add --at "2026-11-05 19:00" --account bonka --file ~/Videos/a.mp4 --caption "..."

Banyak sekaligus dari CSV (lihat `contoh-jadwal.csv`):

    python3 bonka_poster.py schedule import contoh-jadwal.csv

Lihat/hapus: `schedule list`, `schedule remove <id>`, `schedule retry <id>`

## 4. Supaya jadwal jalan otomatis
Pilih salah satu:
- **Hermes**: minta Hermes membuat cron job tiap 5 menit yang menjalankan
  `python3 ~/bonka-poster/bonka_poster.py run --json`.
- **Cron Mac**: `crontab -e`, tambahkan baris:

      */5 * * * * /usr/bin/python3 $HOME/bonka-poster/bonka_poster.py run >> $HOME/.bonka-poster/cron.log 2>&1

Komputer harus menyala (tidak sleep) saat jadwal tiba.

## 5. Mode
- `draft` (bawaan): video masuk inbox TikTok, Anda tinggal tekan Post di aplikasi → bisa publik.
- `direct`: langsung terbit. **Sebelum app lolos review TikTok, hasilnya selalu private.**
  Setelah lolos: `python3 bonka_poster.py setup --default-mode direct` (dan ganti ke client key Production).

## 6. Hermes
Salin folder `hermes-skill/tiktok-poster` ke folder skills Hermes
(biasanya `~/.hermes/skills/`). Lalu cukup perintahkan, mis.:
"Posting ~/Videos/a.mp4 ke TikTok akun bonka besok jam 7 malam dengan caption ...".

## Label promosi
Video promosi produk sendiri / affiliate Shopee → pakai `--brand-organic`
(TikTok mewajibkan pengungkapan konten komersial).

Log: `~/.bonka-poster/poster.log`
