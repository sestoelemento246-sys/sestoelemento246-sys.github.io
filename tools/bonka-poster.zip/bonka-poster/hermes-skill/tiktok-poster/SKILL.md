---
name: tiktok-poster
description: Upload, schedule and manage TikTok video posts for BONKA via the bonka_poster CLI. Use when asked to post, schedule, list or cancel TikTok videos.
---

# TikTok Poster (BONKA)

Post videos to TikTok through the official Content Posting API using the local CLI
`~/bonka-poster/bonka_poster.py`. Always pass `--json` and read the JSON result.

## Commands

List connected accounts (use the `name` field for `--account`):
    python3 ~/bonka-poster/bonka_poster.py accounts --json

Post now:
    python3 ~/bonka-poster/bonka_poster.py post --json \
      --account <name> --file "/absolute/path/video.mp4" \
      --caption "caption #hashtag" [--mode draft|direct] [--brand-organic]

Schedule (local time, or relative +30m / +2h / +1d):
    python3 ~/bonka-poster/bonka_poster.py schedule add --json \
      --at "2026-11-05 19:00" --account <name> --file "/abs/path.mp4" --caption "..."

List / cancel / retry schedule:
    python3 ~/bonka-poster/bonka_poster.py schedule list --json
    python3 ~/bonka-poster/bonka_poster.py schedule remove <id> --json
    python3 ~/bonka-poster/bonka_poster.py schedule retry <id> --json

Process due items (run this every 5 minutes from a cron job):
    python3 ~/bonka-poster/bonka_poster.py run --json

## Rules
- Modes: `draft` sends the video to the creator's TikTok inbox (they finish posting in the app);
  `direct` publishes immediately. Omit `--mode` to use the configured default.
- Until the app passes TikTok review, `direct` posts are forced to `SELF_ONLY` (private). Do not
  try to work around this.
- If the video promotes BONKA's own products or affiliate products, add `--brand-organic`.
  Use `--branded-content` only for paid partnerships (cannot be private).
- Use absolute file paths. Supported: .mp4, .mov.
- On `"ok": false`, report the `error` message to the user. If it says the token expired or no
  account is connected, tell the user to run `python3 ~/bonka-poster/bonka_poster.py login`
  themselves (it needs a browser) — never ask for or handle the client secret.
- Never post the same file twice unless the user asks; check `schedule list` first.
