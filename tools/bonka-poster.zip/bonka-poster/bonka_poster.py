#!/usr/bin/env python3
"""
BONKA Auto Poster - upload video ke TikTok (Content Posting API) dari baris perintah.

Dirancang supaya bisa dipanggil manusia maupun agen AI (mis. Hermes):
setiap perintah mendukung --json untuk output yang mudah dibaca mesin.

Hanya memakai library standar Python (3.8+), tidak perlu pip install.

Perintah utama:
  login                  Hubungkan akun TikTok (sekali per akun)
  accounts               Daftar akun yang terhubung
  post                   Upload satu video sekarang
  schedule add|list|remove
  run                    Proses jadwal yang sudah jatuh tempo (dipanggil cron / agen)
  daemon                 Jalan terus, cek jadwal tiap 60 detik
  status                 Cek status publish_id
"""
import argparse
import json
import math
import mimetypes
import os
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from datetime import datetime, timedelta

API = os.environ.get("BONKA_API", "https://open.tiktokapis.com")
AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
SCOPES = "user.info.basic,video.publish,video.upload"

HOME = os.environ.get("BONKA_HOME") or os.path.join(os.path.expanduser("~"), ".bonka-poster")
CONFIG_FILE = os.path.join(HOME, "config.json")
TOKENS_FILE = os.path.join(HOME, "tokens.json")
SCHEDULE_FILE = os.path.join(HOME, "schedule.json")
LOG_FILE = os.path.join(HOME, "poster.log")
LOCK_FILE = os.path.join(HOME, "run.lock")

MB = 1024 * 1024
SINGLE_CHUNK_MAX = 64 * MB
CHUNK_SIZE = 10 * MB

PRIVACY_LEVELS = ["PUBLIC_TO_EVERYONE", "MUTUAL_FOLLOW_FRIENDS", "FOLLOWER_OF_CREATOR", "SELF_ONLY"]


class PosterError(Exception):
    pass


# ---------------------------------------------------------------- storage

def ensure_home():
    os.makedirs(HOME, exist_ok=True)
    try:
        os.chmod(HOME, 0o700)
    except OSError:
        pass


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def save_json(path, data):
    ensure_home()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def log(msg):
    ensure_home()
    line = "%s  %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_config():
    cfg = load_json(CONFIG_FILE, None)
    if not cfg or not cfg.get("client_key") or not cfg.get("client_secret"):
        raise PosterError("Belum disetel. Jalankan dulu: python3 bonka_poster.py setup")
    cfg.setdefault("redirect_uri", "https://sestoelemento246-sys.github.io/callback.html")
    cfg.setdefault("default_mode", "draft")
    return cfg


# ---------------------------------------------------------------- http

def http(method, url, token=None, json_body=None, form=None, data=None, headers=None, timeout=120):
    h = dict(headers or {})
    body = None
    if token:
        h["Authorization"] = "Bearer " + token
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        h["Content-Type"] = "application/json; charset=UTF-8"
    elif form is not None:
        body = urllib.parse.urlencode(form).encode("utf-8")
        h["Content-Type"] = "application/x-www-form-urlencoded"
    elif data is not None:
        body = data
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            status = r.status
    except urllib.error.HTTPError as e:
        raw = e.read()
        status = e.code
    except urllib.error.URLError as e:
        raise PosterError("Gagal terhubung ke %s: %s" % (url, e.reason))
    text = raw.decode("utf-8", "replace") if raw else ""
    try:
        parsed = json.loads(text) if text else {}
    except ValueError:
        parsed = {"raw": text}
    return status, parsed


def api_call(method, path, token, json_body=None):
    status, res = http(method, API + path, token=token, json_body=json_body)
    err = res.get("error") or {}
    code = err.get("code", "ok") if isinstance(err, dict) else "ok"
    if status >= 400 or (code and code != "ok"):
        msg = err.get("message", "") if isinstance(err, dict) else ""
        raise PosterError("TikTok API error (%s) %s: %s %s" % (status, path, code, msg))
    return res.get("data", {})


# ---------------------------------------------------------------- auth

def build_auth_url(cfg, state):
    q = {
        "client_key": cfg["client_key"],
        "scope": SCOPES,
        "response_type": "code",
        "redirect_uri": cfg["redirect_uri"],
        "state": state,
    }
    return AUTH_URL + "?" + urllib.parse.urlencode(q)


def exchange_code(cfg, code):
    status, res = http("POST", API + "/v2/oauth/token/", form={
        "client_key": cfg["client_key"],
        "client_secret": cfg["client_secret"],
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": cfg["redirect_uri"],
    })
    if status >= 400 or "access_token" not in res:
        raise PosterError("Gagal menukar kode login: %s" % json.dumps(res))
    return res


def refresh(cfg, acct):
    status, res = http("POST", API + "/v2/oauth/token/", form={
        "client_key": cfg["client_key"],
        "client_secret": cfg["client_secret"],
        "grant_type": "refresh_token",
        "refresh_token": acct["refresh_token"],
    })
    if status >= 400 or "access_token" not in res:
        raise PosterError("Token akun %s kedaluwarsa, login ulang: %s" % (acct.get("name"), json.dumps(res)))
    store_tokens(acct, res)
    return acct


def store_tokens(acct, res):
    now = time.time()
    acct["access_token"] = res["access_token"]
    acct["refresh_token"] = res.get("refresh_token", acct.get("refresh_token"))
    acct["expires_at"] = now + int(res.get("expires_in", 86400)) - 300
    acct["refresh_expires_at"] = now + int(res.get("refresh_expires_in", 31536000))
    acct["scope"] = res.get("scope", acct.get("scope"))
    acct["open_id"] = res.get("open_id", acct.get("open_id"))


def get_account(cfg, name=None):
    tokens = load_json(TOKENS_FILE, {})
    if not tokens:
        raise PosterError("Belum ada akun terhubung. Jalankan: python3 bonka_poster.py login")
    if name:
        key = find_account_key(tokens, name)
        if not key:
            raise PosterError("Akun '%s' tidak ditemukan. Akun tersedia: %s" % (name, ", ".join(a["name"] for a in tokens.values())))
    else:
        if len(tokens) > 1:
            raise PosterError("Ada beberapa akun, sebutkan --account. Tersedia: %s" % ", ".join(a["name"] for a in tokens.values()))
        key = next(iter(tokens))
    acct = tokens[key]
    if time.time() >= acct.get("expires_at", 0):
        refresh(cfg, acct)
        tokens[key] = acct
        save_json(TOKENS_FILE, tokens)
    return acct


def find_account_key(tokens, name):
    n = name.lower().lstrip("@")
    for k, a in tokens.items():
        if n in (k.lower(), a.get("name", "").lower(), a.get("username", "").lower(), a.get("display_name", "").lower()):
            return k
    return None


# ---------------------------------------------------------------- posting

def chunk_plan(size):
    if size <= 0:
        raise PosterError("File video kosong.")
    if size <= SINGLE_CHUNK_MAX:
        return size, 1
    count = size // CHUNK_SIZE
    return CHUNK_SIZE, count


def upload_file(upload_url, path, size, chunk_size, count):
    ctype = mimetypes.guess_type(path)[0] or "video/mp4"
    with open(path, "rb") as f:
        for i in range(count):
            start = i * chunk_size
            end = size - 1 if i == count - 1 else start + chunk_size - 1
            f.seek(start)
            data = f.read(end - start + 1)
            for attempt in range(3):
                status, res = http("PUT", upload_url, data=data, headers={
                    "Content-Type": ctype,
                    "Content-Length": str(len(data)),
                    "Content-Range": "bytes %d-%d/%d" % (start, end, size),
                }, timeout=600)
                if status in (200, 201, 206):
                    break
                if attempt == 2:
                    raise PosterError("Upload potongan %d/%d gagal (HTTP %s): %s" % (i + 1, count, status, res))
                time.sleep(3 * (attempt + 1))


def creator_info(acct):
    return api_call("POST", "/v2/post/publish/creator_info/query/", acct["access_token"], json_body={})


def wait_status(acct, publish_id, timeout=300):
    deadline = time.time() + timeout
    last = {}
    while time.time() < deadline:
        last = api_call("POST", "/v2/post/publish/status/fetch/", acct["access_token"], {"publish_id": publish_id})
        st = last.get("status")
        if st in ("PUBLISH_COMPLETE", "SEND_TO_USER_INBOX"):
            return last
        if st == "FAILED":
            raise PosterError("TikTok menolak video: %s" % last.get("fail_reason", "unknown"))
        time.sleep(5)
    last["status"] = last.get("status", "UNKNOWN") + " (masih diproses)"
    return last


def post_video(cfg, account=None, file=None, caption="", mode=None, privacy=None,
               disable_comment=False, disable_duet=False, disable_stitch=False,
               brand_organic=False, branded_content=False, wait=True):
    mode = mode or cfg.get("default_mode", "draft")
    if mode not in ("draft", "direct"):
        raise PosterError("mode harus 'draft' atau 'direct'")
    path = os.path.abspath(os.path.expanduser(file))
    if not os.path.isfile(path):
        raise PosterError("File tidak ditemukan: %s" % path)
    size = os.path.getsize(path)
    chunk_size, count = chunk_plan(size)
    acct = get_account(cfg, account)
    source = {"source": "FILE_UPLOAD", "video_size": size, "chunk_size": chunk_size, "total_chunk_count": count}
    result = {"account": acct.get("name"), "file": path, "mode": mode}

    if mode == "direct":
        info = creator_info(acct)
        options = info.get("privacy_level_options") or []
        if not privacy:
            privacy = "PUBLIC_TO_EVERYONE" if "PUBLIC_TO_EVERYONE" in options else "SELF_ONLY"
        if options and privacy not in options:
            raise PosterError("Privasi %s tidak diizinkan untuk akun ini. Pilihan: %s. "
                              "(App yang belum lolos review hanya boleh SELF_ONLY.)" % (privacy, ", ".join(options)))
        if branded_content and privacy == "SELF_ONLY":
            raise PosterError("Konten berbayar/branded tidak boleh diposting private (aturan TikTok).")
        post_info = {
            "title": caption or "",
            "privacy_level": privacy,
            "disable_comment": bool(disable_comment or info.get("comment_disabled")),
            "disable_duet": bool(disable_duet or info.get("duet_disabled")),
            "disable_stitch": bool(disable_stitch or info.get("stitch_disabled")),
            "video_cover_timestamp_ms": 1000,
            "brand_organic_toggle": bool(brand_organic),
            "brand_content_toggle": bool(branded_content),
        }
        data = api_call("POST", "/v2/post/publish/video/init/", acct["access_token"],
                        {"post_info": post_info, "source_info": source})
        result["privacy"] = privacy
        result["creator"] = info.get("creator_nickname") or info.get("creator_username")
    else:
        data = api_call("POST", "/v2/post/publish/inbox/video/init/", acct["access_token"], {"source_info": source})
        result["note"] = "Video dikirim ke inbox TikTok sebagai draft. Buka aplikasi TikTok untuk mem-posting."
        if caption:
            result["caption_to_paste"] = caption

    publish_id = data.get("publish_id")
    upload_url = data.get("upload_url")
    if not publish_id or not upload_url:
        raise PosterError("Respons init tidak lengkap: %s" % data)
    result["publish_id"] = publish_id
    upload_file(upload_url, path, size, chunk_size, count)
    log("UPLOADED %s -> %s (%s) publish_id=%s" % (path, acct.get("name"), mode, publish_id))
    if wait:
        st = wait_status(acct, publish_id)
        result["status"] = st.get("status")
        if st.get("publicaly_available_post_id"):
            result["post_id"] = st.get("publicaly_available_post_id")
    return result


# ---------------------------------------------------------------- schedule

def parse_when(s):
    s = s.strip()
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    if s.startswith("+"):
        unit = s[-1]
        n = int(s[1:-1])
        mult = {"m": 1, "h": 60, "d": 1440}.get(unit)
        if mult:
            return datetime.now() + timedelta(minutes=n * mult)
    raise PosterError("Format waktu tidak dikenal: '%s'. Pakai 'YYYY-MM-DD HH:MM' (waktu lokal) atau '+30m', '+2h', '+1d'." % s)


def schedule_add(args):
    when = parse_when(args.at)
    path = os.path.abspath(os.path.expanduser(args.file))
    if not os.path.isfile(path):
        raise PosterError("File tidak ditemukan: %s" % path)
    items = load_json(SCHEDULE_FILE, [])
    item = {
        "id": uuid.uuid4().hex[:8],
        "at": when.strftime("%Y-%m-%d %H:%M"),
        "account": args.account,
        "file": path,
        "caption": args.caption or "",
        "mode": args.mode,
        "privacy": args.privacy,
        "brand_organic": args.brand_organic,
        "branded_content": args.branded_content,
        "status": "pending",
        "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    items.append(item)
    save_json(SCHEDULE_FILE, items)
    log("SCHEDULED %s at %s" % (item["id"], item["at"]))
    return item


def import_csv(path):
    import csv
    added = []
    with open(os.path.expanduser(path), newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            row = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
            if not row.get("file") or not row.get("at"):
                continue
            ns = argparse.Namespace(
                at=row["at"], file=row["file"], caption=row.get("caption", ""),
                account=row.get("account") or None, mode=row.get("mode") or None,
                privacy=row.get("privacy") or None,
                brand_organic=row.get("brand_organic", "").lower() in ("1", "true", "ya", "yes"),
                branded_content=row.get("branded_content", "").lower() in ("1", "true", "ya", "yes"),
            )
            added.append(schedule_add(ns))
    return added


def run_due(cfg):
    ensure_home()
    if os.path.exists(LOCK_FILE) and time.time() - os.path.getmtime(LOCK_FILE) < 3600:
        return {"skipped": "run lain masih berjalan"}
    open(LOCK_FILE, "w").close()
    done = []
    try:
        items = load_json(SCHEDULE_FILE, [])
        now = datetime.now()
        for it in items:
            if it.get("status") != "pending":
                continue
            if parse_when(it["at"]) > now:
                continue
            it["status"] = "running"
            save_json(SCHEDULE_FILE, items)
            try:
                res = post_video(cfg, account=it.get("account"), file=it["file"], caption=it.get("caption", ""),
                                 mode=it.get("mode"), privacy=it.get("privacy"),
                                 brand_organic=it.get("brand_organic"), branded_content=it.get("branded_content"))
                it["status"] = "done"
                it["result"] = res
                log("DONE %s %s" % (it["id"], res.get("status")))
            except Exception as e:  # noqa
                it["status"] = "failed"
                it["error"] = str(e)
                log("FAILED %s %s" % (it["id"], e))
            it["finished"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            save_json(SCHEDULE_FILE, items)
            done.append(it)
    finally:
        try:
            os.remove(LOCK_FILE)
        except OSError:
            pass
    return {"processed": done}


# ---------------------------------------------------------------- cli

def out(args, data, human=None):
    if getattr(args, "json", False):
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print(human if human is not None else json.dumps(data, indent=2, ensure_ascii=False))


def cmd_setup(args):
    cfg = load_json(CONFIG_FILE, {})
    print("Ambil Client key & Client secret di developers.tiktok.com > app BONKA Auto Poster")
    print("(pakai yang di tab Sandbox selama app belum lolos review).\n")
    ck = args.client_key or input("Client key: ").strip()
    cs = args.client_secret or input("Client secret: ").strip()
    cfg.update({"client_key": ck, "client_secret": cs})
    cfg.setdefault("redirect_uri", "https://sestoelemento246-sys.github.io/callback.html")
    cfg["default_mode"] = args.default_mode or cfg.get("default_mode", "draft")
    save_json(CONFIG_FILE, cfg)
    print("\nTersimpan di %s" % CONFIG_FILE)


def cmd_login(args):
    cfg = load_config()
    state = secrets.token_urlsafe(16)
    url = build_auth_url(cfg, state)
    code = args.code
    if not code:
        print("1) Buka link ini (akan terbuka otomatis), login dengan akun TikTok yang mau dihubungkan:\n")
        print("   " + url + "\n")
        if not args.no_browser:
            try:
                webbrowser.open(url)
            except Exception:
                pass
        print("2) Setelah klik 'Authorize', halaman BONKA akan menampilkan kode. Klik 'Copy code'.")
        code = input("3) Tempel kode di sini lalu Enter: ").strip()
    code = urllib.parse.unquote(code)
    res = exchange_code(cfg, code)
    acct = {}
    store_tokens(acct, res)
    try:
        u = api_call("GET", "/v2/user/info/?fields=open_id,display_name,avatar_url,username", acct["access_token"])
        user = u.get("user", {})
        acct["display_name"] = user.get("display_name", "")
        acct["username"] = user.get("username", "")
    except PosterError:
        pass
    acct["name"] = args.name or acct.get("username") or acct.get("display_name") or acct["open_id"][:8]
    tokens = load_json(TOKENS_FILE, {})
    tokens[acct["open_id"]] = acct
    save_json(TOKENS_FILE, tokens)
    log("LOGIN %s" % acct["name"])
    out(args, {"ok": True, "account": acct["name"], "display_name": acct.get("display_name")},
        "Berhasil terhubung: %s (%s)" % (acct["name"], acct.get("display_name", "")))


def cmd_accounts(args):
    tokens = load_json(TOKENS_FILE, {})
    rows = [{"name": a.get("name"), "display_name": a.get("display_name"), "username": a.get("username"),
             "refresh_valid_until": datetime.fromtimestamp(a.get("refresh_expires_at", 0)).strftime("%Y-%m-%d")}
            for a in tokens.values()]
    if args.json:
        out(args, rows)
    elif not rows:
        print("Belum ada akun. Jalankan: python3 bonka_poster.py login")
    else:
        for r in rows:
            print("- %s  (%s)  login berlaku s/d %s" % (r["name"], r["display_name"], r["refresh_valid_until"]))


def cmd_post(args):
    cfg = load_config()
    res = post_video(cfg, account=args.account, file=args.file, caption=args.caption, mode=args.mode,
                     privacy=args.privacy, disable_comment=args.disable_comment, disable_duet=args.disable_duet,
                     disable_stitch=args.disable_stitch, brand_organic=args.brand_organic,
                     branded_content=args.branded_content, wait=not args.no_wait)
    out(args, res)


def cmd_creator(args):
    cfg = load_config()
    out(args, creator_info(get_account(cfg, args.account)))


def cmd_status(args):
    cfg = load_config()
    acct = get_account(cfg, args.account)
    out(args, api_call("POST", "/v2/post/publish/status/fetch/", acct["access_token"], {"publish_id": args.publish_id}))


def cmd_schedule(args):
    if args.action == "add":
        out(args, schedule_add(args))
    elif args.action == "import":
        out(args, import_csv(args.csv))
    elif args.action == "list":
        items = load_json(SCHEDULE_FILE, [])
        if not args.all:
            items = [i for i in items if i.get("status") in ("pending", "running", "failed")]
        if args.json:
            out(args, items)
        elif not items:
            print("Tidak ada jadwal.")
        else:
            for i in sorted(items, key=lambda x: x["at"]):
                print("[%s] %s  %-8s  %-7s  %s  %s" % (i["id"], i["at"], i["status"], i.get("mode") or "default",
                                                       i.get("account") or "-", os.path.basename(i["file"])))
                if i.get("error"):
                    print("          error: %s" % i["error"])
    elif args.action == "remove":
        items = load_json(SCHEDULE_FILE, [])
        new = [i for i in items if i["id"] != args.id]
        save_json(SCHEDULE_FILE, new)
        out(args, {"removed": len(items) - len(new)})
    elif args.action == "retry":
        items = load_json(SCHEDULE_FILE, [])
        for i in items:
            if i["id"] == args.id:
                i["status"] = "pending"
                i.pop("error", None)
        save_json(SCHEDULE_FILE, items)
        out(args, {"ok": True})


def cmd_run(args):
    out(args, run_due(load_config()))


def cmd_daemon(args):
    cfg = load_config()
    print("Daemon berjalan, cek jadwal tiap %d detik. Ctrl+C untuk berhenti." % args.interval)
    while True:
        try:
            r = run_due(cfg)
            for it in r.get("processed", []):
                print("%s  %s  %s" % (datetime.now().strftime("%H:%M"), it["id"], it["status"]))
        except Exception as e:  # noqa
            log("DAEMON ERROR %s" % e)
            print("error:", e)
        time.sleep(args.interval)


def add_post_opts(p, schedule=False):
    p.add_argument("--account", help="nama/username akun (wajib jika >1 akun)")
    p.add_argument("--file", required=True, help="path file video (.mp4/.mov)")
    p.add_argument("--caption", default="", help="caption + hashtag")
    p.add_argument("--mode", choices=["draft", "direct"], help="draft = ke inbox TikTok; direct = langsung terbit")
    p.add_argument("--privacy", choices=PRIVACY_LEVELS, help="khusus mode direct")
    p.add_argument("--brand-organic", action="store_true", help="promosi bisnis/produk sendiri (label Promotional content)")
    p.add_argument("--branded-content", action="store_true", help="konten berbayar/kerja sama brand (label Paid partnership)")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bonka_poster", description="BONKA Auto Poster untuk TikTok")
    ap.add_argument("--json", action="store_true", help="output JSON (untuk agen AI)")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("setup", help="simpan client key/secret")
    p.add_argument("--client-key")
    p.add_argument("--client-secret")
    p.add_argument("--default-mode", choices=["draft", "direct"])
    p.set_defaults(fn=cmd_setup)

    p = sub.add_parser("login", help="hubungkan akun TikTok")
    p.add_argument("--name", help="nama panggilan akun, mis. bonka")
    p.add_argument("--code", help="kode dari halaman callback (opsional)")
    p.add_argument("--no-browser", action="store_true")
    p.set_defaults(fn=cmd_login)

    p = sub.add_parser("accounts", help="daftar akun")
    p.set_defaults(fn=cmd_accounts)

    p = sub.add_parser("post", help="upload video sekarang")
    add_post_opts(p)
    p.add_argument("--disable-comment", action="store_true")
    p.add_argument("--disable-duet", action="store_true")
    p.add_argument("--disable-stitch", action="store_true")
    p.add_argument("--no-wait", action="store_true", help="jangan tunggu status selesai")
    p.set_defaults(fn=cmd_post)

    p = sub.add_parser("creator-info", help="cek pilihan privasi & batas durasi akun")
    p.add_argument("--account")
    p.set_defaults(fn=cmd_creator)

    p = sub.add_parser("status", help="cek status publish")
    p.add_argument("publish_id")
    p.add_argument("--account")
    p.set_defaults(fn=cmd_status)

    p = sub.add_parser("schedule", help="kelola jadwal")
    ss = p.add_subparsers(dest="action")
    a = ss.add_parser("add", help="tambah jadwal")
    a.add_argument("--at", required=True, help="'YYYY-MM-DD HH:MM' waktu lokal, atau +30m/+2h/+1d")
    add_post_opts(a, schedule=True)
    a = ss.add_parser("import", help="impor jadwal dari CSV")
    a.add_argument("csv")
    a = ss.add_parser("list", help="lihat jadwal")
    a.add_argument("--all", action="store_true", help="termasuk yang sudah selesai")
    a = ss.add_parser("remove", help="hapus jadwal")
    a.add_argument("id")
    a = ss.add_parser("retry", help="ulangi jadwal yang gagal")
    a.add_argument("id")
    p.set_defaults(fn=cmd_schedule)

    p = sub.add_parser("run", help="proses jadwal yang jatuh tempo")
    p.set_defaults(fn=cmd_run)

    p = sub.add_parser("daemon", help="jalan terus & cek jadwal")
    p.add_argument("--interval", type=int, default=60)
    p.set_defaults(fn=cmd_daemon)

    argv = list(sys.argv[1:] if argv is None else argv)
    want_json = "--json" in argv
    argv = [a for a in argv if a != "--json"]
    args = ap.parse_args(argv)
    args.json = want_json
    if not getattr(args, "fn", None) or (args.cmd == "schedule" and not args.action):
        ap.print_help()
        return 2
    try:
        args.fn(args)
        return 0
    except PosterError as e:
        if args.json:
            print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
        else:
            print("ERROR: %s" % e, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
